﻿namespace Datos.Dtos
{
    public class EndpointCreateDto
    {
        public string? Url { get; set; }

        public string? Tipo { get; set; }
    }
}
