﻿namespace Datos.Dtos
{
    public class UsuarioCreateDto
    {
        public string? Mail { get; set; }
        public string? Pwd { get; set; }
        public string? Login { get; set; }
    }
}
