﻿namespace Datos.Dtos
{
    public class MonedaDto
    {
        public string? Nombre { get; set; }
    }
}
