﻿namespace Datos.Dtos
{
    public class ParametroCreateDto
    {
        public string? Tipo { get; set; }
        public string? Valor { get; set; }
        public string? Mapea { get; set; }
    }
}
